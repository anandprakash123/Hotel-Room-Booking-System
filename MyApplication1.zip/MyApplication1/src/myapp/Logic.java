/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myapp;
import java.sql.*;
import javax.swing.JTextField;

/**
 *
 * @author sys-user
 */
public class Logic {
    Connection a;
    PreparedStatement b;
    ResultSet c;

    public Logic() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            a = DriverManager.getConnection("jdbc:mysql://localhost/logics", "root", "root");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean reg(String Name, String age, String mail, String phone, String address) {

        try {
            b = a.prepareStatement("insert into reg(Name,age,mail,phone,address) values(?,?,?,?,?)");
            b.setString(1, Name);
            b.setString(2, age);
            b.setString(3, mail);
            b.setString(4, phone);
            b.setString(5, address);
           
            int res = b.executeUpdate();
            if (res > 0) {
                return true;
            }
        } catch (Exception e) {
        }
        return false;
    }
    
    public boolean logic(String name,String pass){
        try {
            b=a.prepareStatement("select * from logic where Name=? and Password=?");
            b.setString(1, name);
            b.setString(2, pass);
            c=b.executeQuery();
            if(c.next()){
                return true;
            }
        } catch (Exception e) {
        }
        return false;
    }
     
    public boolean customer(String Name, int Persons, int Days,String from,String to,int NoofRooms,String Roomtype,int total) {

        try {
            b = a.prepareStatement("insert into customer(Name,Persons,Days,FromD,ToD,NoofRooms,Roomtype,total) values(?,?,?,?,?,?,?,?)");
            b.setString(1, Name);
            b.setInt(2, Persons);
            b.setInt(3, Days);
            b.setString(4, from);
            b.setString(5, to);
            b.setInt(6, NoofRooms);
            b.setString(7, Roomtype);
            b.setInt(8, total);
            int res = b.executeUpdate();
            if (res > 0) {
                return true;
            }
        } catch (Exception e) {
        }
        return false;
    }
     public ResultSet vacant()
     {
         try
         {
             b=a.prepareStatement("select * from vacant1");
             c=b.executeQuery();
            
         }
         catch(Exception e)
         {
         }
         return c;
         }
     public ResultSet customer()
     {
         try
         {
             b=a.prepareStatement("select * from customer");
             c=b.executeQuery();
            
         }
         catch(Exception e)
         {
         }
         return c;
         }
     public ResultSet reg()
     {
         try
         {
             b=a.prepareStatement("select * from reg");
             c=b.executeQuery();
            
         }
         catch(Exception e)
         {
         }
         return c;
         }
     public ResultSet engaged()
     {
         try
         {
             b=a.prepareStatement("select * from engaged3");
             c=b.executeQuery();
            
         }
         catch(Exception e)
         {
         }
         return c;
         }
      public ResultSet Total(String name)
     {
         try
         {
             b=a.prepareStatement("select * from customer where Name=?");
             b.setString(1,name);
             c=b.executeQuery();
            
         }
         catch(Exception e)
         {
         }
         return c;
     }
       public ResultSet detail(String name)
     {
         try
         {
             b=a.prepareStatement("select * from  reg where name=?");
             b.setString(1,name);
             c=b.executeQuery();
            
         }
         catch(Exception e)
         {
         }
         return c;
     }
      
     }
       




    

     




    

